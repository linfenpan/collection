;~function(window, NAME){

// 构建 transition 动画
    var DOM_ELEM = document.documentElement, ID = +new Date;

/////////////////////////// 样式构建部分
    // 生成 pre, enter, leave 三中样式
    function createStyleInfo(obj){
        var style = "", id = "scroll_reveal_" + ID++;
        // obj: {pre, enter, leave, pre_wait, pre_over, pre_tf, leave_wait, leave_over, leave_tf}
        var inline = "-webkit-transform-style:preserve-3d; transform-style:preserve-3d;";
        var preStyle = getClassContext(obj, id, "pre");
        var leaveStyle = getClassContext(obj, id, "leave", true);
        var enterStyle = getClassContext(obj, id, "enter", true);

        // 离开时间
        var leaveTime = obj["leave"] ? parseFloat(obj["leave_wait"]) + parseFloat(obj["leave_over"]) : 0;
        // 数序不要乱了哈~
        // style = [preStyle, enterStyle, leaveStyle].join("\n") + "\n\n\n";
        return {
            pre    : preStyle,
            enter  : enterStyle,
            leave  : leaveStyle,
            inline : inline,
            time   : leaveTime,
            id     : id
        };
    }
    // 获取 class 内容
    function getClassContext(obj, id, name, needTransition){
        var str = obj[name] ? [
            //"." + getClass(id, name) + "{",
                needTransition ? getCssTransition(obj[name + "_over"], obj[name + "_tf"], obj[name + "_wait"]) : "",
                getCssTransform( obj[name] ),
                "opacity:" + (obj[name + "_opacity"] || 0) + ";",
            // "}"
        ].join(" ") : "";
        return str;
    }
    // 进入、离开、预设，3个类
    function getClass(key, suffix){
        return key + "_" + suffix;
    }
    // 动画执行函数
    function getCssTransition(time, timeFn, delay){
        return "-webkit-transition:transform $0, opacity: $0;-ms-transition:transform $0, opacity $0;transition:transform $0, opacity $0;".replace(/\$0/g, time + " " + timeFn + " " + delay);
    }
    // 变换函数
    function getCssTransform(transition){
        return "-webkit-transform:$0;-ms-transform:$0;transform:$0;".replace(/\$0/g, transition);
    }
/////////////////////////// 样式构建部分

/////////////////////////// 词法分析 部分
    // 词法 替换字符串
    function lexicalAnalysisReplace(str, arr){
        return str.replace(/\$(\d+)/g, function(str, num){
            return arr[num];
        });
    };
    // 词法表
    var lexicalAnalysisMap = {
        x: "translateX($1)",
        y: "translateY($1)",
        z: "translateZ($1)",
        rx: "rotateX($1)",
        ry: "rotateY($1)",
        rz: "rotateZ($1)",
        r: "rotate($1)",
        sx: "scaleX($1)",
        sy: "scaleY($1)",
        sz: "scaleZ($1)",
        s: "scale($1)"
    };
    // 词法分析
    // "enter x|10% y|20% rx|10deg ry|10deg rz|10deg s|1.2, over 2s, wait .6s, tf ease, leave x|20%, wait .2s, over .5s"
    function lexicalAnalysis(str){
        var words = str.split(/[ ,]+/),
            obj = {enter: "", pre: "", leave: ""},  // 进入、预设，离开 3 部分的样式
            curKey = "enter";

        var map = lexicalAnalysisMap, key = "";
        for(var i = 0, max = words.length; i < max; i++){
            key = words[i];
            if(key){
                switch(key){
                    case "enter":
                        // 进入，其实在预处理样式里
                        curKey = "enter";
                        break;
                    case "opacity": // 透明度
                        if(curKey == "enter"){
                            obj["pre_opacity"] = words[++i];
                            break;
                        }
                    case "wait":    // 延迟时间
                    case "over":    // 持续时间
                    case "tf":  // 动画时间函数
                        obj[curKey + "_" + key] = words[++i];
                        break;
                    case "leave":
                        curKey = "leave";
                        break;
                    default:
                        var arr = key.split("|"), key = map[arr[0]];
                        if(key){
                            if( curKey == "enter" ){
                                // 进入时，应该把所有预处理的样式清空，所以，进入的样式，都是初始值
                                obj[curKey] += " " + lexicalAnalysisReplace(key, [0, /^s[xyz]?/.test(key) ? 1 : 0]);
                                obj["pre"] += " " + lexicalAnalysisReplace(key, arr);
                            }else{
                                obj[curKey] += " " + lexicalAnalysisReplace(key, arr);
                            }
                        };
                }
            }
        };

        // 如果 leave 不存在，则使用 enter 的所有
        // enter 就复制所有 pre 的属性
        var list = ["_wait", "_over", "_tf"];
        for(var i = 0, max = list.length; i < max; i++){
            var item = list[i], val = obj["enter" + item];
            if( !obj["leave" + item] ){
                obj["leave" + item] = val;
            }
        }
        obj["leave"] = obj["leave"] || obj["pre"];

        // 生成的 object是:
        // {enter: "", pre: "", pre_opacity: "", pre_wait: "", pre_over: "", pre-tf: "", leave: "", leave_opacity: "", leave_wait: "", leave_over: "", leave_tf: ""}
        return obj;
    };
/////////////////////////// 词法分析 部分


    /**
     * @param cf {Object} 配置文件
     *  dom: 根元素，默认 document.documentElement
     *  key: 需要遍历的dom，保存数据的属性，默认 data-ctr
     *  default: 默认动画配置，默认: enter x|10% opacity 0 over .5s wait 0s tf ease
     */
    function buildTransition(cf){
        this.reset(cf);
    };
    buildTransition.prototype = {
        // 重设配置
        reset: function(cf){
            if( typeof cf === "object" ){
                this.dom = cf.dom || DOM_ELEM;

                this.key = cf.key || "data-ctr";
                this.keyId = this.key + "-id";      // 动画class的名字
                this.keyTime = this.key + "-leavetime";  // 动画延迟

                // 内联样式
                this.keyStyleInline = this.key + "-inlinestyle";
                this.keyStyleLeave = this.key + "-leavestyle";
                this.keyStyleEnter = this.key + "-enterstyle";
                this.keyStylePre = this.key + "-prestyle";

                // 默认动画配置，一般，必须配置齐全咧~
                this.def_config = lexicalAnalysis(cf["default"] || "enter x|10% opacity 0 over .5s wait 0s tf ease");
            }
            // 元素列表
            this.domList = this.dom.querySelectorAll("[" + this.key + "]");

            // 开始对所有元素，进行词法分析
            this.analysisiDomList();
        },
        // 返回 dom 列表
        getDomList: function(){
            return this.domList;
        },
        // 对元素进行词法分析
        analysisiDomList: function(){
            var domList = this.domList, keyId = this.keyId, key = this.key;

            var elem, obj, item;
            for(var i = 0, max = domList.length; i < max; i++){
                elem = domList[i];
                // 防止重复初始化
                if( !elem.getAttribute(keyId) ){
                    // 词法分析
                    obj = lexicalAnalysis( elem.getAttribute(key) );
                    // 与默认值合并
                    this.combineWithDefault(obj);
                    // 生成样式
                    item = createStyleInfo(obj);
                    // 给元素设置相关属性
                    this.setElemInfo(elem, item);
                }
            }
        },
        // 设置元素相关的属性
        setElemInfo: function(elem, item){
            var keyId = this.keyId, keyTime = this.keyTime;

            // 记录下样式ID
            elem.setAttribute(keyId, item.id);
            elem.setAttribute(keyTime, item.time);

            var inline = (elem.getAttribute("style") || "") + item.inline;

            // 设置inline样式
            elem.setAttribute(this.keyStyleInline, inline);
            // 设置 预设 样式
            elem.setAttribute(this.keyStylePre, inline + item.pre);
            // 设置 进入 样式
            elem.setAttribute(this.keyStyleEnter, inline + item.enter);
            // 设置 离开 样式
            elem.setAttribute(this.keyStyleLeave, inline + item.leave);
            // 把样式，设置为 预 设 样式
            elem.setAttribute("style", inline + item.pre);
        },
        // 当前配置对象，与 def_config 对象，进行合并
        combineWithDefault: function(obj){
            var map = this.def_config;
            for(var i in map){
                // 因为都是字符串，所以，不用担心
                obj[i] = obj[i] || map[i];
            }
            // 缺少 enter_opacity
            obj["pre_opacity"]   = obj["pre_opacity"] || "0";
            obj["enter_opacity"] = obj["enter_opacity"] || "1";
            obj["leave_opacity"] = obj["leave_opacity"] || obj["pre_opacity"] || "0";
        },
        // 某个孩子，执行动画
        enter: function(list){

            this._aEach(list, function(elem, id){
                elem.setAttribute("style", elem.getAttribute(this.keyStylePre));
                var self = this;
                setTimeout(function(){
                    elem.setAttribute("style", elem.getAttribute(self.keyStyleEnter));
                }, 0);
            });
        },
        // 某个孩子，执行动画
        leave: function(list){
            var keyTime = this.keyTime;
            this._aEach(list, function(elem, id){
                elem.setAttribute("style", elem.getAttribute(this.keyStyleLeave));
            });
        },
        // 这个乱调用，会出错哦~
        _aEach: function(list, cb){
            if(typeof list === "undefined"){
                list = this.domList;
            }else if( !("length" in list) ){
                list = [list];
            }
            for(var i = 0, max = list.length, elem, id; i < max; i++){
                elem = list[i], id = elem.getAttribute(this.keyId);
                if( id ){
                    cb.call(this, elem, id);
                }
            }
        }
    };
    window[NAME] = buildTransition;

}(window, window.CSS3_TRANSITION_NAME || "Css3Transition");
